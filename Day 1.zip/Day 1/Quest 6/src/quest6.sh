sh keygen.sh
ls
cd key
rm file*
sh unifier.sh
